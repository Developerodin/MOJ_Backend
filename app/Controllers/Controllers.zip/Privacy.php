<?php

namespace App\Controllers;


use CodeIgniter\HTTP\Response;
use CodeIgniter\HTTP\ResponseInterface;
use Exception;


use ReflectionException;
class Privacy extends BaseController
{
    public function index()
    {
        
        return view('Privacy');
    }
    
   
   
}
